# UEA Time Series Classification

[![Build Status](https://travis-ci.com/goastler/uea-tsc.svg?branch=master)](https://travis-ci.com/goastler/uea-tsc)

Find more info on our [website](http://www.timeseriesclassification.com).
