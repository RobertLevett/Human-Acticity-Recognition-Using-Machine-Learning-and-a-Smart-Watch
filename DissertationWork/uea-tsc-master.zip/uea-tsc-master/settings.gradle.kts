rootProject.name = "uea-tsc"

